import { Injectable } from '@angular/core';
import { Project, Task } from  '../models/project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private projects: Project[] = [
    { id: 1, name: 'Projet 1', description: 'Description du projet 1', tasks: [] },
    { id: 2, name: 'Projet 2', description: 'Description du projet 2', tasks: [] }
  ];

  getProjects(): Project[] {
    return this.projects;
  }

  addProject(project: Project) {
    this.projects.push({ ...project, id: this.projects.length + 1, tasks: [] });
  }

  updateProject(updatedProject: Project) {
    const index = this.projects.findIndex(p => p.id === updatedProject.id);
    if (index !== -1) {
      this.projects[index] = updatedProject;
    }
  }

  deleteProject(id: number) {
    this.projects = this.projects.filter(p => p.id !== id);
  }

  addTask(projectId: number, task: Task) {
    const project = this.projects.find(p => p.id === projectId);
    if (project) {
      project.tasks.push({ ...task, id: project.tasks.length + 1 });
    }
  }
}
