import { Component, EventEmitter, Output } from '@angular/core';
import { Project } from '../../models/project';

@Component({
  selector: 'app-project-form',
  templateUrl: './project-form.component.html',
  styleUrls: ['./project-form.component.css']
})
export class ProjectFormComponent {
  project: Project = { id: 0, name: '', description: '', tasks: [] };
  @Output() projectAdded = new EventEmitter<Project>();

  onSubmit() {
    this.projectAdded.emit(this.project);
    this.project = { id: 0, name: '', description: '', tasks: [] }; // Reset form
  }
}
