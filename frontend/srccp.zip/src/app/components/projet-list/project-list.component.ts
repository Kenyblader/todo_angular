import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../../services/project.service';
import { Project } from '../../models/project';
import { Task } from '../../models/task.model';

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {
  projects: Project[] = [];

  constructor(private projectService: ProjectService) {}

  ngOnInit() {
    this.projects = this.projectService.getProjects();
  }

  addProject(project: Project) {
    this.projectService.addProject(project);
  }

  editProject(project: Project) {
    const newName = prompt('Nouveau nom', project.name);
    const newDesc = prompt('Nouvelle description', project.description);
    if (newName && newDesc) {
      this.projectService.updateProject({ ...project, name: newName, description: newDesc });
    }
  }

  deleteProject(id: number) {
    this.projectService.deleteProject(id);
  }

  addTask(task: Task, projectId: number) {
    this.projectService.addTask(projectId, task);
  }
}
