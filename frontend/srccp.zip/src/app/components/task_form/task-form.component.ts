import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Task } from '../../models/task.model';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent {
  @Input() projectId!: number;
  task: Task = { id: 0, title: '', completed: false };
  @Output() taskAdded = new EventEmitter<Task>();

  onSubmit() {
    this.taskAdded.emit(this.task);
    this.task = { id: 0, title: '', completed: false }; // Reset form
  }
}
